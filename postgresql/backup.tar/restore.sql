--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mistral;
--
-- Name: mistral; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mistral WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE mistral OWNER TO postgres;

\connect mistral

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.activity_log (
    id integer NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    message text NOT NULL,
    activity_source_id smallint NOT NULL,
    activity_type_id smallint NOT NULL
);


ALTER TABLE public.activity_log OWNER TO jdooley;

--
-- Name: activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_log_id_seq OWNER TO jdooley;

--
-- Name: activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;


--
-- Name: activity_source; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.activity_source (
    id smallint NOT NULL,
    name character varying(50) NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.activity_source OWNER TO jdooley;

--
-- Name: activity_type; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.activity_type (
    id smallint NOT NULL,
    name character varying(50) NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.activity_type OWNER TO jdooley;

--
-- Name: album; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.album (
    id integer NOT NULL,
    title character varying(120) NOT NULL,
    title_lower character varying(120) NOT NULL,
    artist_id integer NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.album OWNER TO jdooley;

--
-- Name: album_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.album_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.album_id_seq OWNER TO jdooley;

--
-- Name: album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.album_id_seq OWNED BY public.album.id;


--
-- Name: artist; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.artist (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    name_lower character varying(100) NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.artist OWNER TO jdooley;

--
-- Name: artist_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.artist_id_seq OWNER TO jdooley;

--
-- Name: artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.artist_id_seq OWNED BY public.artist.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    title character varying(10),
    first_name character varying(30),
    last_name character varying(50),
    address character varying(60),
    city character varying(40),
    state character varying(20),
    country character varying(30),
    post_code character varying(20),
    phone character varying(20),
    fax character varying(20),
    email character varying(120),
    employee_id integer,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.customer OWNER TO jdooley;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_id_seq OWNER TO jdooley;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    title character varying(10),
    first_name character varying(30),
    last_name character varying(50),
    date_of_birth date,
    hire_date date,
    address character varying(60),
    city character varying(40),
    state character varying(20),
    country character varying(30),
    post_code character varying(20),
    phone character varying(20),
    fax character varying(20),
    email character varying(120),
    manager_id integer NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.employee OWNER TO jdooley;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_id_seq OWNER TO jdooley;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: genre; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.genre (
    id integer NOT NULL,
    name character varying(30) NOT NULL,
    name_lower character varying(30) NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.genre OWNER TO jdooley;

--
-- Name: genre_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.genre_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genre_id_seq OWNER TO jdooley;

--
-- Name: genre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.genre_id_seq OWNED BY public.genre.id;


--
-- Name: invoice; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.invoice (
    id integer NOT NULL,
    invoice_date date NOT NULL,
    address character varying(60),
    city character varying(40),
    state character varying(20),
    country character varying(30),
    post_code character varying(20),
    total integer NOT NULL,
    customer_id integer NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.invoice OWNER TO jdooley;

--
-- Name: invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_id_seq OWNER TO jdooley;

--
-- Name: invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.invoice_id_seq OWNED BY public.invoice.id;


--
-- Name: invoice_item; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.invoice_item (
    id integer NOT NULL,
    quantity smallint NOT NULL,
    unit_price smallint NOT NULL,
    track_id integer NOT NULL,
    invoice_id integer NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.invoice_item OWNER TO jdooley;

--
-- Name: invoice_item_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.invoice_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_item_id_seq OWNER TO jdooley;

--
-- Name: invoice_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.invoice_item_id_seq OWNED BY public.invoice_item.id;


--
-- Name: media_type; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.media_type (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    name_lower character varying(40) NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.media_type OWNER TO jdooley;

--
-- Name: media_type_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.media_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_type_id_seq OWNER TO jdooley;

--
-- Name: media_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.media_type_id_seq OWNED BY public.media_type.id;


--
-- Name: playlist; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.playlist (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    name_lower character varying(50) NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.playlist OWNER TO jdooley;

--
-- Name: playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.playlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.playlist_id_seq OWNER TO jdooley;

--
-- Name: playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.playlist_id_seq OWNED BY public.playlist.id;


--
-- Name: playlist_track; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.playlist_track (
    id integer NOT NULL,
    playlist_id integer NOT NULL,
    track_id integer NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.playlist_track OWNER TO jdooley;

--
-- Name: playlist_track_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.playlist_track_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.playlist_track_id_seq OWNER TO jdooley;

--
-- Name: playlist_track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.playlist_track_id_seq OWNED BY public.playlist_track.id;


--
-- Name: track; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.track (
    id integer NOT NULL,
    name character varying(1500) NOT NULL,
    name_lower character varying(1500) NOT NULL,
    composer character varying(200),
    milliseconds integer NOT NULL,
    bytes integer NOT NULL,
    unit_price numeric(6,2) NOT NULL,
    album_id integer NOT NULL,
    genre_id integer NOT NULL,
    media_type_id integer NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.track OWNER TO jdooley;

--
-- Name: track_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.track_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.track_id_seq OWNER TO jdooley;

--
-- Name: track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.track_id_seq OWNED BY public.track.id;


--
-- Name: version; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.version (
    id smallint NOT NULL,
    major smallint NOT NULL,
    minor smallint NOT NULL,
    build smallint NOT NULL,
    is_valid boolean DEFAULT false NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.version OWNER TO jdooley;

--
-- Name: version_item; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.version_item (
    id integer NOT NULL,
    step character varying(40) NOT NULL,
    comment character varying(500) NOT NULL,
    version_id smallint NOT NULL,
    lock_version smallint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.version_item OWNER TO jdooley;

--
-- Name: version_item_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.version_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_item_id_seq OWNER TO jdooley;

--
-- Name: version_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.version_item_id_seq OWNED BY public.version_item.id;


--
-- Name: xxx_album; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_album (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    title character varying(120),
    title_lower character varying(120),
    artist_id integer,
    lock_version smallint
);


ALTER TABLE public.xxx_album OWNER TO jdooley;

--
-- Name: xxx_album_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_album_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_album_id_seq OWNER TO jdooley;

--
-- Name: xxx_album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_album_id_seq OWNED BY public.xxx_album.id;


--
-- Name: xxx_artist; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_artist (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    name character varying(100),
    name_lower character varying(100),
    lock_version smallint
);


ALTER TABLE public.xxx_artist OWNER TO jdooley;

--
-- Name: xxx_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_artist_id_seq OWNER TO jdooley;

--
-- Name: xxx_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_artist_id_seq OWNED BY public.xxx_artist.id;


--
-- Name: xxx_customer; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_customer (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    title character varying(10),
    first_name character varying(30),
    last_name character varying(50),
    address character varying(60),
    city character varying(40),
    state character varying(20),
    country character varying(30),
    post_code character varying(20),
    phone character varying(20),
    fax character varying(20),
    email character varying(120),
    employee_id integer,
    lock_version smallint
);


ALTER TABLE public.xxx_customer OWNER TO jdooley;

--
-- Name: xxx_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_customer_id_seq OWNER TO jdooley;

--
-- Name: xxx_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_customer_id_seq OWNED BY public.xxx_customer.id;


--
-- Name: xxx_employee; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_employee (
    id integer NOT NULL,
    title character varying(10),
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(50),
    date_of_birth date,
    hire_date date,
    address character varying(60),
    city character varying(40),
    state character varying(20),
    country character varying(30),
    post_code character varying(20),
    phone character varying(20),
    fax character varying(20),
    email character varying(120),
    manager_id integer,
    lock_version smallint
);


ALTER TABLE public.xxx_employee OWNER TO jdooley;

--
-- Name: xxx_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_employee_id_seq OWNER TO jdooley;

--
-- Name: xxx_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_employee_id_seq OWNED BY public.xxx_employee.id;


--
-- Name: xxx_genre; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_genre (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    name character varying(30),
    name_lower character varying(30),
    lock_version smallint
);


ALTER TABLE public.xxx_genre OWNER TO jdooley;

--
-- Name: xxx_genre_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_genre_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_genre_id_seq OWNER TO jdooley;

--
-- Name: xxx_genre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_genre_id_seq OWNED BY public.xxx_genre.id;


--
-- Name: xxx_invoice; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_invoice (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    invoice_date date,
    address character varying(60),
    city character varying(40),
    state character varying(20),
    country character varying(30),
    post_code character varying(20),
    total integer,
    customer_id integer,
    lock_version smallint
);


ALTER TABLE public.xxx_invoice OWNER TO jdooley;

--
-- Name: xxx_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_invoice_id_seq OWNER TO jdooley;

--
-- Name: xxx_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_invoice_id_seq OWNED BY public.xxx_invoice.id;


--
-- Name: xxx_invoice_item; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_invoice_item (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    quantity smallint,
    unit_price smallint,
    track_id integer,
    invoice_id integer,
    lock_version smallint
);


ALTER TABLE public.xxx_invoice_item OWNER TO jdooley;

--
-- Name: xxx_invoice_item_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_invoice_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_invoice_item_id_seq OWNER TO jdooley;

--
-- Name: xxx_invoice_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_invoice_item_id_seq OWNED BY public.xxx_invoice_item.id;


--
-- Name: xxx_media_type; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_media_type (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    name character varying(40),
    name_lower character varying(40),
    lock_version smallint
);


ALTER TABLE public.xxx_media_type OWNER TO jdooley;

--
-- Name: xxx_media_type_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_media_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_media_type_id_seq OWNER TO jdooley;

--
-- Name: xxx_media_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_media_type_id_seq OWNED BY public.xxx_media_type.id;


--
-- Name: xxx_playlist; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_playlist (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    name character varying(50),
    name_lower character varying(50),
    lock_version smallint
);


ALTER TABLE public.xxx_playlist OWNER TO jdooley;

--
-- Name: xxx_playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_playlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_playlist_id_seq OWNER TO jdooley;

--
-- Name: xxx_playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_playlist_id_seq OWNED BY public.xxx_playlist.id;


--
-- Name: xxx_playlist_track; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_playlist_track (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    playlist_id integer,
    track_id integer,
    lock_version smallint
);


ALTER TABLE public.xxx_playlist_track OWNER TO jdooley;

--
-- Name: xxx_playlist_track_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_playlist_track_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_playlist_track_id_seq OWNER TO jdooley;

--
-- Name: xxx_playlist_track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_playlist_track_id_seq OWNED BY public.xxx_playlist_track.id;


--
-- Name: xxx_track; Type: TABLE; Schema: public; Owner: jdooley
--

CREATE TABLE public.xxx_track (
    id integer NOT NULL,
    action character(1) NOT NULL,
    logged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    record_id integer NOT NULL,
    name character varying(1500),
    name_lower character varying(1500),
    composer character varying(200),
    milliseconds integer,
    bytes integer,
    unit_price numeric(6,2),
    album_id integer,
    genre_id integer,
    media_type_id integer,
    lock_version smallint
);


ALTER TABLE public.xxx_track OWNER TO jdooley;

--
-- Name: xxx_track_id_seq; Type: SEQUENCE; Schema: public; Owner: jdooley
--

CREATE SEQUENCE public.xxx_track_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.xxx_track_id_seq OWNER TO jdooley;

--
-- Name: xxx_track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jdooley
--

ALTER SEQUENCE public.xxx_track_id_seq OWNED BY public.xxx_track.id;


--
-- Name: activity_log id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_log ALTER COLUMN id SET DEFAULT nextval('public.activity_log_id_seq'::regclass);


--
-- Name: album id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.album ALTER COLUMN id SET DEFAULT nextval('public.album_id_seq'::regclass);


--
-- Name: artist id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.artist ALTER COLUMN id SET DEFAULT nextval('public.artist_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: genre id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.genre ALTER COLUMN id SET DEFAULT nextval('public.genre_id_seq'::regclass);


--
-- Name: invoice id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.invoice ALTER COLUMN id SET DEFAULT nextval('public.invoice_id_seq'::regclass);


--
-- Name: invoice_item id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.invoice_item ALTER COLUMN id SET DEFAULT nextval('public.invoice_item_id_seq'::regclass);


--
-- Name: media_type id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.media_type ALTER COLUMN id SET DEFAULT nextval('public.media_type_id_seq'::regclass);


--
-- Name: playlist id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.playlist ALTER COLUMN id SET DEFAULT nextval('public.playlist_id_seq'::regclass);


--
-- Name: playlist_track id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.playlist_track ALTER COLUMN id SET DEFAULT nextval('public.playlist_track_id_seq'::regclass);


--
-- Name: track id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.track ALTER COLUMN id SET DEFAULT nextval('public.track_id_seq'::regclass);


--
-- Name: version_item id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.version_item ALTER COLUMN id SET DEFAULT nextval('public.version_item_id_seq'::regclass);


--
-- Name: xxx_album id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_album ALTER COLUMN id SET DEFAULT nextval('public.xxx_album_id_seq'::regclass);


--
-- Name: xxx_artist id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_artist ALTER COLUMN id SET DEFAULT nextval('public.xxx_artist_id_seq'::regclass);


--
-- Name: xxx_customer id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_customer ALTER COLUMN id SET DEFAULT nextval('public.xxx_customer_id_seq'::regclass);


--
-- Name: xxx_employee id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_employee ALTER COLUMN id SET DEFAULT nextval('public.xxx_employee_id_seq'::regclass);


--
-- Name: xxx_genre id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_genre ALTER COLUMN id SET DEFAULT nextval('public.xxx_genre_id_seq'::regclass);


--
-- Name: xxx_invoice id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_invoice ALTER COLUMN id SET DEFAULT nextval('public.xxx_invoice_id_seq'::regclass);


--
-- Name: xxx_invoice_item id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_invoice_item ALTER COLUMN id SET DEFAULT nextval('public.xxx_invoice_item_id_seq'::regclass);


--
-- Name: xxx_media_type id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_media_type ALTER COLUMN id SET DEFAULT nextval('public.xxx_media_type_id_seq'::regclass);


--
-- Name: xxx_playlist id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_playlist ALTER COLUMN id SET DEFAULT nextval('public.xxx_playlist_id_seq'::regclass);


--
-- Name: xxx_playlist_track id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_playlist_track ALTER COLUMN id SET DEFAULT nextval('public.xxx_playlist_track_id_seq'::regclass);


--
-- Name: xxx_track id; Type: DEFAULT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_track ALTER COLUMN id SET DEFAULT nextval('public.xxx_track_id_seq'::regclass);


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.activity_log (id, logged_at, message, activity_source_id, activity_type_id) FROM stdin;
\.
COPY public.activity_log (id, logged_at, message, activity_source_id, activity_type_id) FROM '$$PATH$$/3871.dat';

--
-- Data for Name: activity_source; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.activity_source (id, name, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.activity_source (id, name, lock_version, created_at, updated_at) FROM '$$PATH$$/3868.dat';

--
-- Data for Name: activity_type; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.activity_type (id, name, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.activity_type (id, name, lock_version, created_at, updated_at) FROM '$$PATH$$/3869.dat';

--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.album (id, title, title_lower, artist_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.album (id, title, title_lower, artist_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3881.dat';

--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.artist (id, name, name_lower, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.artist (id, name, name_lower, lock_version, created_at, updated_at) FROM '$$PATH$$/3873.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.customer (id, title, first_name, last_name, address, city, state, country, post_code, phone, fax, email, employee_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.customer (id, title, first_name, last_name, address, city, state, country, post_code, phone, fax, email, employee_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3889.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.employee (id, title, first_name, last_name, date_of_birth, hire_date, address, city, state, country, post_code, phone, fax, email, manager_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.employee (id, title, first_name, last_name, date_of_birth, hire_date, address, city, state, country, post_code, phone, fax, email, manager_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3887.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.genre (id, name, name_lower, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.genre (id, name, name_lower, lock_version, created_at, updated_at) FROM '$$PATH$$/3875.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.invoice (id, invoice_date, address, city, state, country, post_code, total, customer_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.invoice (id, invoice_date, address, city, state, country, post_code, total, customer_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3891.dat';

--
-- Data for Name: invoice_item; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.invoice_item (id, quantity, unit_price, track_id, invoice_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.invoice_item (id, quantity, unit_price, track_id, invoice_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3893.dat';

--
-- Data for Name: media_type; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.media_type (id, name, name_lower, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.media_type (id, name, name_lower, lock_version, created_at, updated_at) FROM '$$PATH$$/3877.dat';

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.playlist (id, name, name_lower, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.playlist (id, name, name_lower, lock_version, created_at, updated_at) FROM '$$PATH$$/3879.dat';

--
-- Data for Name: playlist_track; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.playlist_track (id, playlist_id, track_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.playlist_track (id, playlist_id, track_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3885.dat';

--
-- Data for Name: track; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.track (id, name, name_lower, composer, milliseconds, bytes, unit_price, album_id, genre_id, media_type_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.track (id, name, name_lower, composer, milliseconds, bytes, unit_price, album_id, genre_id, media_type_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3883.dat';

--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.version (id, major, minor, build, is_valid, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.version (id, major, minor, build, is_valid, lock_version, created_at, updated_at) FROM '$$PATH$$/3865.dat';

--
-- Data for Name: version_item; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.version_item (id, step, comment, version_id, lock_version, created_at, updated_at) FROM stdin;
\.
COPY public.version_item (id, step, comment, version_id, lock_version, created_at, updated_at) FROM '$$PATH$$/3867.dat';

--
-- Data for Name: xxx_album; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_album (id, action, logged_at, record_id, title, title_lower, artist_id, lock_version) FROM stdin;
\.
COPY public.xxx_album (id, action, logged_at, record_id, title, title_lower, artist_id, lock_version) FROM '$$PATH$$/3903.dat';

--
-- Data for Name: xxx_artist; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_artist (id, action, logged_at, record_id, name, name_lower, lock_version) FROM stdin;
\.
COPY public.xxx_artist (id, action, logged_at, record_id, name, name_lower, lock_version) FROM '$$PATH$$/3895.dat';

--
-- Data for Name: xxx_customer; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_customer (id, action, logged_at, record_id, title, first_name, last_name, address, city, state, country, post_code, phone, fax, email, employee_id, lock_version) FROM stdin;
\.
COPY public.xxx_customer (id, action, logged_at, record_id, title, first_name, last_name, address, city, state, country, post_code, phone, fax, email, employee_id, lock_version) FROM '$$PATH$$/3911.dat';

--
-- Data for Name: xxx_employee; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_employee (id, title, action, logged_at, record_id, first_name, last_name, date_of_birth, hire_date, address, city, state, country, post_code, phone, fax, email, manager_id, lock_version) FROM stdin;
\.
COPY public.xxx_employee (id, title, action, logged_at, record_id, first_name, last_name, date_of_birth, hire_date, address, city, state, country, post_code, phone, fax, email, manager_id, lock_version) FROM '$$PATH$$/3909.dat';

--
-- Data for Name: xxx_genre; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_genre (id, action, logged_at, record_id, name, name_lower, lock_version) FROM stdin;
\.
COPY public.xxx_genre (id, action, logged_at, record_id, name, name_lower, lock_version) FROM '$$PATH$$/3897.dat';

--
-- Data for Name: xxx_invoice; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_invoice (id, action, logged_at, record_id, invoice_date, address, city, state, country, post_code, total, customer_id, lock_version) FROM stdin;
\.
COPY public.xxx_invoice (id, action, logged_at, record_id, invoice_date, address, city, state, country, post_code, total, customer_id, lock_version) FROM '$$PATH$$/3913.dat';

--
-- Data for Name: xxx_invoice_item; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_invoice_item (id, action, logged_at, record_id, quantity, unit_price, track_id, invoice_id, lock_version) FROM stdin;
\.
COPY public.xxx_invoice_item (id, action, logged_at, record_id, quantity, unit_price, track_id, invoice_id, lock_version) FROM '$$PATH$$/3915.dat';

--
-- Data for Name: xxx_media_type; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_media_type (id, action, logged_at, record_id, name, name_lower, lock_version) FROM stdin;
\.
COPY public.xxx_media_type (id, action, logged_at, record_id, name, name_lower, lock_version) FROM '$$PATH$$/3899.dat';

--
-- Data for Name: xxx_playlist; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_playlist (id, action, logged_at, record_id, name, name_lower, lock_version) FROM stdin;
\.
COPY public.xxx_playlist (id, action, logged_at, record_id, name, name_lower, lock_version) FROM '$$PATH$$/3901.dat';

--
-- Data for Name: xxx_playlist_track; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_playlist_track (id, action, logged_at, record_id, playlist_id, track_id, lock_version) FROM stdin;
\.
COPY public.xxx_playlist_track (id, action, logged_at, record_id, playlist_id, track_id, lock_version) FROM '$$PATH$$/3907.dat';

--
-- Data for Name: xxx_track; Type: TABLE DATA; Schema: public; Owner: jdooley
--

COPY public.xxx_track (id, action, logged_at, record_id, name, name_lower, composer, milliseconds, bytes, unit_price, album_id, genre_id, media_type_id, lock_version) FROM stdin;
\.
COPY public.xxx_track (id, action, logged_at, record_id, name, name_lower, composer, milliseconds, bytes, unit_price, album_id, genre_id, media_type_id, lock_version) FROM '$$PATH$$/3905.dat';

--
-- Name: activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.activity_log_id_seq', 414, true);


--
-- Name: album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.album_id_seq', 350, false);


--
-- Name: artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.artist_id_seq', 280, false);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.customer_id_seq', 1, false);


--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.employee_id_seq', 1, false);


--
-- Name: genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.genre_id_seq', 30, false);


--
-- Name: invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.invoice_id_seq', 420, false);


--
-- Name: invoice_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.invoice_item_id_seq', 1, false);


--
-- Name: media_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.media_type_id_seq', 10, false);


--
-- Name: playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.playlist_id_seq', 20, false);


--
-- Name: playlist_track_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.playlist_track_id_seq', 9000, false);


--
-- Name: track_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.track_id_seq', 3600, false);


--
-- Name: version_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.version_item_id_seq', 16, true);


--
-- Name: xxx_album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_album_id_seq', 347, true);


--
-- Name: xxx_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_artist_id_seq', 275, true);


--
-- Name: xxx_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_customer_id_seq', 59, true);


--
-- Name: xxx_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_employee_id_seq', 8, true);


--
-- Name: xxx_genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_genre_id_seq', 25, true);


--
-- Name: xxx_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_invoice_id_seq', 412, true);


--
-- Name: xxx_invoice_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_invoice_item_id_seq', 2240, true);


--
-- Name: xxx_media_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_media_type_id_seq', 5, true);


--
-- Name: xxx_playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_playlist_id_seq', 18, true);


--
-- Name: xxx_playlist_track_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_playlist_track_id_seq', 8715, true);


--
-- Name: xxx_track_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jdooley
--

SELECT pg_catalog.setval('public.xxx_track_id_seq', 3479, true);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: activity_source activity_source_name; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_source
    ADD CONSTRAINT activity_source_name UNIQUE (name);


--
-- Name: activity_source activity_source_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_source
    ADD CONSTRAINT activity_source_pkey PRIMARY KEY (id);


--
-- Name: activity_type activity_type_name; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_type
    ADD CONSTRAINT activity_type_name UNIQUE (name);


--
-- Name: activity_type activity_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_type
    ADD CONSTRAINT activity_type_pkey PRIMARY KEY (id);


--
-- Name: album album_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT album_pkey PRIMARY KEY (id);


--
-- Name: artist artist_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT artist_pkey PRIMARY KEY (id);


--
-- Name: customer customer_email_key; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_email_key UNIQUE (email);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: employee employee_email_key; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_email_key UNIQUE (email);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: genre genre_name_key; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.genre
    ADD CONSTRAINT genre_name_key UNIQUE (name);


--
-- Name: genre genre_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.genre
    ADD CONSTRAINT genre_pkey PRIMARY KEY (id);


--
-- Name: invoice_item invoice_item_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.invoice_item
    ADD CONSTRAINT invoice_item_pkey PRIMARY KEY (id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- Name: media_type media_type_name_key; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.media_type
    ADD CONSTRAINT media_type_name_key UNIQUE (name);


--
-- Name: media_type media_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.media_type
    ADD CONSTRAINT media_type_pkey PRIMARY KEY (id);


--
-- Name: playlist playlist_name_key; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_name_key UNIQUE (name);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id);


--
-- Name: playlist_track playlist_track_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.playlist_track
    ADD CONSTRAINT playlist_track_pkey PRIMARY KEY (id);


--
-- Name: track track_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT track_pkey PRIMARY KEY (id);


--
-- Name: version version_build; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_build UNIQUE (major, minor, build);


--
-- Name: version_item version_item_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.version_item
    ADD CONSTRAINT version_item_pkey PRIMARY KEY (id);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (id);


--
-- Name: xxx_album xxx_album_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_album
    ADD CONSTRAINT xxx_album_pkey PRIMARY KEY (id);


--
-- Name: xxx_artist xxx_artist_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_artist
    ADD CONSTRAINT xxx_artist_pkey PRIMARY KEY (id);


--
-- Name: xxx_customer xxx_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_customer
    ADD CONSTRAINT xxx_customer_pkey PRIMARY KEY (id);


--
-- Name: xxx_employee xxx_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_employee
    ADD CONSTRAINT xxx_employee_pkey PRIMARY KEY (id);


--
-- Name: xxx_genre xxx_genre_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_genre
    ADD CONSTRAINT xxx_genre_pkey PRIMARY KEY (id);


--
-- Name: xxx_invoice_item xxx_invoice_item_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_invoice_item
    ADD CONSTRAINT xxx_invoice_item_pkey PRIMARY KEY (id);


--
-- Name: xxx_invoice xxx_invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_invoice
    ADD CONSTRAINT xxx_invoice_pkey PRIMARY KEY (id);


--
-- Name: xxx_media_type xxx_media_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_media_type
    ADD CONSTRAINT xxx_media_type_pkey PRIMARY KEY (id);


--
-- Name: xxx_playlist xxx_playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_playlist
    ADD CONSTRAINT xxx_playlist_pkey PRIMARY KEY (id);


--
-- Name: xxx_playlist_track xxx_playlist_track_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_playlist_track
    ADD CONSTRAINT xxx_playlist_track_pkey PRIMARY KEY (id);


--
-- Name: xxx_track xxx_track_pkey; Type: CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.xxx_track
    ADD CONSTRAINT xxx_track_pkey PRIMARY KEY (id);


--
-- Name: activity_log activity_log_activity_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_activity_source_id_fkey FOREIGN KEY (activity_source_id) REFERENCES public.activity_source(id);


--
-- Name: activity_log activity_log_activity_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_activity_type_id_fkey FOREIGN KEY (activity_type_id) REFERENCES public.activity_type(id);


--
-- Name: album album_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT album_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artist(id);


--
-- Name: customer customer_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employee(id);


--
-- Name: employee employee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_fkey FOREIGN KEY (manager_id) REFERENCES public.employee(id);


--
-- Name: invoice invoice_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: invoice_item invoice_item_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.invoice_item
    ADD CONSTRAINT invoice_item_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice(id);


--
-- Name: invoice_item invoice_item_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.invoice_item
    ADD CONSTRAINT invoice_item_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.track(id);


--
-- Name: playlist_track playlist_track_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.playlist_track
    ADD CONSTRAINT playlist_track_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES public.playlist(id);


--
-- Name: playlist_track playlist_track_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.playlist_track
    ADD CONSTRAINT playlist_track_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.track(id);


--
-- Name: track track_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT track_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.album(id);


--
-- Name: track track_genre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT track_genre_id_fkey FOREIGN KEY (genre_id) REFERENCES public.genre(id);


--
-- Name: track track_media_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT track_media_type_id_fkey FOREIGN KEY (media_type_id) REFERENCES public.media_type(id);


--
-- Name: version_item version_item_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jdooley
--

ALTER TABLE ONLY public.version_item
    ADD CONSTRAINT version_item_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.version(id);


--
-- PostgreSQL database dump complete
--

